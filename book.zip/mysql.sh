/usr/local/mysql/bin/mysql -uroot -pShmily00
