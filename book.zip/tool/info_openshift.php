<?php
	$host="localhost";
	$user="admin6X2sjA6";
	$pwd="Shmily00";
	$pwd="fCY57JZgdDgK";
	$db_name="book";
?>
