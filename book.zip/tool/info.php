<?php
	$host="127.0.0.1";
	$user="root";
	$pwd="Shmily00";
	$db_name="book";
?>
