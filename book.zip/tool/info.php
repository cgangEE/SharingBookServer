<?php
	$host="127.0.0.1";
	$user="root";
	$pwd="Shmily00";
	$db_name="book";
	$uploadUrl = "http://172.27.35.4/book/upload/";
?>
